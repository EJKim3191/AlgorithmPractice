

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class Algo2_서울_8반_김응주 {
	// testcase
	public static int T;
	// 정점과 간선
	public static int V, E;
	// 노드 정보들을 담기 위한 arraylist
	public static ArrayList<Node> arr;
	//bfs 를 위한 queue
	public static Queue<Integer> q;
	// 숫자 마킹을 위한 배열
	public static int[] num;
	// 마지막 결과 값을 출력 하기 위한 boolean
	public static boolean result;
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer str = null;
		StringBuilder sb = new StringBuilder();
		//첫줄 입력
		T=Integer.parseInt(bfr.readLine());
		//테스트케이스 for문
		for(int i=1; i<=T; i++) {
			//실수하지 않기 위해 testcase 마다 초기화
			arr=new ArrayList<>();
			//정점과 간선 입력
			str= new StringTokenizer(bfr.readLine());
			V=Integer.parseInt(str.nextToken());
			E=Integer.parseInt(str.nextToken());
			//정점은 1부터 V까지
			num=new int[V+1];
			//간선 정보 입력
			for(int j=0; j<E; j++) {
				str=new StringTokenizer(bfr.readLine());
				int from = Integer.parseInt(str.nextToken());
				int to = Integer.parseInt(str.nextToken());
				arr.add(new Node(from, to));
			}
			//이분 그래프--> 정점 끼리 다른 번호를 매겼을 때 인접한 정점끼린 다른 정보를 갖고있어야한다?
			//생각->bfs or dfs를 활용하여 각 인접 정점에 1과 2 의 숫자를 마킹해준다
			//만약 이미 마킹 되있고, 인접해있는데, 같은숫자다?-> No
			//전부 마킹되었고 문제없다-> Yes
			bfs();
			//결과 출력(stringbuilder)
			if(result) {
				sb.append("YES").append("\n");
			}
			else {
				sb.append("NO").append("\n");
			}
		}
		System.out.println(sb);
	}
	public static void bfs() {
		//테스트 케이스가 있으므로, 실수 하지 않기 위해 매번 초기화
		q=new LinkedList<>();
		//첫 정보 from 입력
		q.add(arr.get(0).from);
		num[arr.get(0).from]=1;
		//기본값 true
		result=true;
		//bfs를 위한 큐
		while(!q.isEmpty()) {
			//비교를 위한 q poll
			int start = q.poll();
			for(int i=0; i<arr.size(); i++) {
				//만약 시작점과 같은 간선 정보를 갖고 있다면
				if(start==arr.get(i).from) {
					//간선 정보에 담겨있는 숫자의 마킹에 따른 비교문
					//from 이 1이라면
					if(num[arr.get(i).from]==1) {
						//to가 1일때 NO! 이분그래프가 아니다
						if(num[arr.get(i).to]==1) {
							result=false;
							//무한루프를 돌지 않기 위한 break
							break;
						}
						//정보가 없거나, 아니라면 2를 담는다
						num[arr.get(i).to]=2;
						q.add(arr.get(i).to);
					}
					//역으로 from이 2라면
					else if(num[arr.get(i).from]==2) {
						//to 가 2일 떄 NO! 이분그래프가 아니다
						if(num[arr.get(i).to]==2) {
							result=false;
							//무한루프를 돌지 않기 위한 break
							break;
						}
						//정보가 없거나, 아니라면 1을 담는다
						num[arr.get(i).to]=1;
						q.add(arr.get(i).to);
					}
				}
				
			}
		}
		
		
	}
}

//노드 정보를 담기 위한 클래스
class Node {
	int from;
	int to;

	public Node(int from, int to) {
		super();
		this.from = from;
		this.to = to;
	}
}
