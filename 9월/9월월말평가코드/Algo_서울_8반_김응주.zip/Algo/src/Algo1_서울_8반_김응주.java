

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class Algo1_서울_8반_김응주 {
	//입력 M, N
	public static int M, N;
	//모든 숫자의 순서
	public static ArrayList<Integer> allNum = new ArrayList<>();
	public static void main(String[] args) throws IOException {
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer str = new StringTokenizer(bfr.readLine());
		StringBuilder sb = new StringBuilder();
		//입력부
		M=Integer.parseInt(str.nextToken());
		N=Integer.parseInt(str.nextToken());
		
		//기본적인 순서가 항상 있다: 1~99까지의 숫자의 나열이 새로운 숫자의 나열로 된다
		//어차피 최대 99개의 숫자 즉-> 최대 99개의 숫자 범위 비교를 통해 나타내면 된다
		//순서는 8/5/4/9/1/7/6/3/2/0
		//항상 1자리수 는 2자리수보다 앞에 온다 (같은 앞자리수 비교시)
		
		int[] num = {8,5,4,9,1,7,6,3,2,0};
		//숫자 넣기->allNum에 서순 대로
		for(int i=0; i<9; i++) {
			//1자리수 부터 넣기
			allNum.add(num[i]);
			for(int j=0; j<10; j++) {
				//같은 첫자리수의 2자리수 넣기
				int temp= num[i]*10+num[j];
				allNum.add(temp);
			}
		}
		//생성된 새로운 숫자의 배열을 바탕으로 주어진 범위값에 비교-> 있다면 담고 없다면 넘어간다
		for(int i=0; i<allNum.size(); i++) {
			if(allNum.get(i)>=M && allNum.get(i)<=N) {
				//바로 출력이기 떄문에 다른곳에 넣지 않고 stringbuilder를 이용하여 담고 출력
				sb.append(allNum.get(i)).append(" ");
			}
		}
		System.out.println(sb);
	}
}
