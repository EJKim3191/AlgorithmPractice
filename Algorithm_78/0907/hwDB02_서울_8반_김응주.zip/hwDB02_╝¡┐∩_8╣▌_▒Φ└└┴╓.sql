use scott;

#1번
select ename 이름, job 업무, sal 급여
from emp;

#2번
select empno 사원번호, ename 이름, job 업무, deptno 부서번호
from emp
where empno not in
(select mgr
from emp
where mgr is not null);

#3번
select ename 이름, job 업무, mgr 상사번호
from emp
where mgr in(select mgr from emp where ename='BLAKE');

#4번
select ename 이름, hiredate 입사일
from emp
order by hiredate
limit 5;

#5번
select ename 이름, job 업무, dname 부서명
from emp
left join dept on emp.deptno=dept.deptno
where mgr in(select empno from emp where ename='JONES');
