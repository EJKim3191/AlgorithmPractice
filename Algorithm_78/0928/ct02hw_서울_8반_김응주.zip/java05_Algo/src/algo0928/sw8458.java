package algo0928;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class sw8458 {
	public static int T;
	public static int N;

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer str = null;
		StringBuilder sb= new StringBuilder();
		T = Integer.parseInt(bfr.readLine());
		
		for (int testCase = 1; testCase <= T; testCase++) {
			N=Integer.parseInt(bfr.readLine());
			int[] dis=new int[N];
			int check=0;
			boolean truth=true;
			int sum=0;
			str=new StringTokenizer(bfr.readLine());
			
			int dx=Integer.parseInt(str.nextToken());
			int dy=Integer.parseInt(str.nextToken());
			dis[0]=Math.abs(dx)+Math.abs(dy);
			for(int i=1; i<N; i++) {
				str=new StringTokenizer(bfr.readLine());
				
				int x=Integer.parseInt(str.nextToken());
				int y=Integer.parseInt(str.nextToken());
				dis[i]=Math.abs(x)+Math.abs(y);
				//모든점 짝or 홀 검사
				if(dis[i]%2!=dis[i-1]%2) truth=false;
			}
			int max=0;
			int count=0;
			for(int i=0; i<dis.length; i++) {
				max= Math.max(max, dis[i]);
			}
			if(truth) {
				while(true) {
					if(sum>=max && Math.abs(max-sum)%2==0) {
						break;
					}
					sum+=++count;
					
					
				}
			}
			else {
				count=-1;
			}
			sb.append("#").append(testCase).append(" ").append(count).append("\n");
		}
		System.out.println(sb);
	}

}
