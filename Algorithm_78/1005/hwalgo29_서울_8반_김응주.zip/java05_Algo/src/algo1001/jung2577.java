package algo1001;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class jung2577 {
	public static int N, d, k, c;
	public static int[] dish;
	public static int[] eat;

	public static void main(String[] args) throws IOException {
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer str = null;

		str = new StringTokenizer(bfr.readLine());
		N = Integer.parseInt(str.nextToken());
		d = Integer.parseInt(str.nextToken());
		k = Integer.parseInt(str.nextToken());
		c = Integer.parseInt(str.nextToken());
		eat= new int[d+1];
		dish = new int[N];
		for (int i = 0; i < N; i++) {
			dish[i] = Integer.parseInt(bfr.readLine());
		}
		int max = 0;
		int cnt = 0;
		for(int i=0; i<k; i++) {
			if(eat[dish[i]]==0) {
				max++;
			}
			eat[dish[i]]+=1;
		}
		cnt=max;
		if(eat[c]==0) max+=1;
		
		int start = k;
		while(true) {
			eat[dish[(start-k)%N]]-=1;
			if(eat[dish[(start-k)%N]]==0) cnt-=1;
			if(eat[dish[start%N]]==0) {
				cnt+=1;
			}
			eat[dish[start%N]]+=1;
			max=Math.max(max, (eat[c]==0)? cnt+1: cnt);
			start+=1;
			if(start==(N-1)+k) break;
		}
		
		System.out.println(max);
	}
}
