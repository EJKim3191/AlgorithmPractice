package hwalgo08_서울_8반_김응주;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Solution_3040 {
	//9C7 구하기
	private static int num[];
	private static int check[];
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));

		num=new int[9];
		for(int i=0; i<9; i++) {
			num[i]=Integer.parseInt(bfr.readLine());
		}
		permu();
		bfr.close();
		
	}
	public static void permu() {
		for(int i=0; i< 1<<9; i++) {
			check=new int[9];
			int sum=0;
			int cnt=0;
			for(int j=0; j<9; j++) {
				if((i & 1<<j)>0) {
					check[j]=1;
					cnt++;
				}
			}
			if(cnt==7) {
				for(int j=0; j<9; j++) {
					if(check[j]==1) {
						sum+=num[j];
					}
				}
				//System.out.println(sum);
				//System.out.println();
			}
			if(sum==100) {
				for(int j=0; j<9; j++) {
					if(check[j]==1) {
						System.out.println(num[j]);
					}
				}
			}
			
		}
	}
}

