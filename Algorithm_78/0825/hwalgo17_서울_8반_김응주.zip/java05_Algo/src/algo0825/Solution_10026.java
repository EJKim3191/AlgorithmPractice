package algo0825;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Solution_10026 {
	public static int N;
	public static char[][] arr;
	public static boolean[][] check;
	public static boolean[][] checkPatient;
	public static int[] dx = { 0, 0, -1, 1 };
	public static int[] dy = { 1, -1, 0, 0 };

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer str = null;
		N = Integer.parseInt(bfr.readLine());
		arr = new char[N][N];
		check = new boolean[N][N];
		checkPatient = new boolean[N][N];
		
		for (int i = 0; i < N; i++) {
			String[] temp=bfr.readLine().split("");
			
			for (int j = 0; j < N; j++) {
				arr[j][i] = temp[j].charAt(0);

			}
		}
		int count=0;
		int countPatient=0;
		for(int i=0; i<N; i++) {
			for(int j=0; j<N; j++) {
				if(!check[i][j]) {
					dfs(j,i);
					count+=1;
				}
				if(!checkPatient[i][j]) {
					patientDfs(j,i);
					countPatient+=1;
				}
			}
		}
		System.out.println(count + " " + countPatient);
		
	}

	public static void dfs(int x, int y) {
		check[y][x] = true;
		for (int i = 0; i < 4; i++) {
			if (!isTrue(x, y, i)) {
				continue;
			}
			if (arr[y][x] != arr[y + dy[i]][x + dx[i]]) {
				continue;
			}
			if (check[y + dy[i]][x + dx[i]]) {
				continue;
			}

			dfs(x + dx[i], y + dy[i]);
		}

	}
	public static void patientDfs(int x, int y) {
		checkPatient[y][x] = true;
		for (int i = 0; i < 4; i++) {
			if (!isTrue(x, y, i))
				continue;
			if ((arr[y][x] =='R' && arr[y+dy[i]][x+dx[i]]=='B') 
					|| (arr[y][x] =='G' && arr[y+dy[i]][x+dx[i]]=='B')
					|| (arr[y][x] =='B' && arr[y+dy[i]][x+dx[i]]=='R')
					|| (arr[y][x] =='B' && arr[y+dy[i]][x+dx[i]]=='G'))
				continue;
			if (checkPatient[y + dy[i]][x + dx[i]])
				continue;

			patientDfs(x + dx[i], y + dy[i]);
		}

	}
	public static boolean isTrue(int x, int y, int i) {
		if (dx[i] + x >= 0 && dy[i] + y >= 0 && dx[i]+x < N && dy[i]+y < N) {
			return true;
		}

		return false;
	}
}
