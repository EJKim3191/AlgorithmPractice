package hwalgo03_서울_8반_김응주;

import java.util.Scanner;

public class Solution9_SW_Expert_Academy2001 {
	static int N;
	static int map[][];
	static int testCase;
	static int M;
	static int sum;
	static StringBuilder sb = new StringBuilder();
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);

		testCase=Integer.parseInt(scn.nextLine());
		for(int k=0; k < testCase; k++) {
			N = scn.nextInt();
			M = scn.nextInt();
			map=new int[N][N];
			//System.out.printf("%d %d %d",testCase, N , M);
			for(int i=0; i<N; i++) {	
				scn.nextLine();
				for(int j=0; j<N; j++) {
					map[i][j] = scn.nextInt();
					//System.out.printf("%d ",map[i][j]);
				}
			}
			sb.append('#');
			sb.append(k+1);
			sb.append(" ");
			search();
		}
		System.out.println(sb);
		scn.close();
		scn=null;
	}
	public static void search() {
		sum=0;
		int dx=0; int dy=0;
		for(int i=0; i<=N-M; i++) {
			for(int j=0; j<=N-M; j++) {
				sum=Math.max(sumMini(M, j, i), sum);
			}
		}
		sb.append(sum);
		sb.append("\n");
	}
	public static int sumMini(int M, int dx, int dy) {
		int midsum=0;
		for(int i=0; i<M; i++) {
			for(int j=0; j<M; j++) {
				midsum+=map[dy+i][dx+j];
			}
		}
		return midsum;
	}
}
