package hwalgo12_서울_8반_김응주;

import java.io.IOException;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Solution1992 {
	public static int N;
	public static int[][] map;
	public static StringBuilder sb = new StringBuilder();

	public static void main(String[] args) throws IOException {
		Scanner scanner = new Scanner(System.in);
		N = scanner.nextInt();
		map = new int[N][N];
		for (int i = 0; i < N; i++) {
			String temp = scanner.next();

			for (int j = 0; j < N; j++) {
				map[i][j] = temp.charAt(j) - '0';
			}
		}
		where(0, 0, N);

		System.out.println(sb);
	}

	public static void where(int x, int y, int N) {
		// 왼위 , 오아래
		if (isPossible(x, y, N)) {
			sb.append(map[y][x]);
			return;
		}
		int temp = N / 2;
		sb.append('(');
		where(x, y, temp);
		where(x + temp, y, temp);
		where(x, y + temp, temp);
		where(x + temp, y + temp, temp);
		sb.append(')');
	}

	public static boolean isPossible(int x, int y, int size) {
		int temp = map[y][x];

		for (int i = y; i < y + size; i++) {
			for (int j = x; j < x + size; j++) {
				if (temp != map[i][j]) {
					return false;
				}
			}
		}

		return true;

	}
}
