package hwalgo13_서울_8반_김응주;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Set;
import java.util.StringTokenizer;

public class Solution_1987 {
	public static char[][] map;
	public static int R,C;
	public static Set<Character> has=new HashSet<>(); //알파벳 개수
	public static int fsum=0;
	public static void main(String[] args) throws IOException {
		
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer str = null;
		str=new StringTokenizer(bfr.readLine());
		R = Integer.parseInt(str.nextToken());
		C = Integer.parseInt(str.nextToken());
		map= new char[R][C];
		//str=new StringTokenizer(bfr.readLine());
		for(int i=0; i<R; i++) {
			map[i] = bfr.readLine().toCharArray();
		}
		move(0,0,1);
		System.out.println(fsum);
		
		//가지치기
		
		
	}
	public static void move(int x, int y, int count) {
		//왼
		has.add(map[y][x]);
		
		if(x-1>=0) {
			if(!has.contains(map[y][x-1])) {
				move(x-1,y,count+1);
			}
		}
		//위
		if(y-1>=0) {
			if(!has.contains(map[y-1][x])) {
				move(x,y-1,count+1);
			}
		}
		//오
		if(x+1<C) {
			if(!has.contains(map[y][x+1])) {
				move(x+1,y,count+1);
			}
		}
		//아
		if(y+1<R) {
			if(!has.contains(map[y+1][x])) {
				
				move(x,y+1,count+1);
			}
		}
		//System.out.println(count);
		has.remove(map[y][x]);

		fsum = fsum > count ? fsum:count;
		
		return;
			
	}
}
