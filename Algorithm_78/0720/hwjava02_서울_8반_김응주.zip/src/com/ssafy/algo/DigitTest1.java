package com.ssafy.algo;

import java.util.Scanner;
// 동적 배열(arraylist 활용?) 혹은 받은 정수의 갯수를 샌 후에 배열을 할당해주나?
public class DigitTest1 {
	public static void countT(int arr[]) {
		int num=0;
		int temp;
		int trr[] = new int[10];
		for(int i=0; i<arr.length; i++) {
			if(arr[i]!=0) {
				temp=arr[i]/10;
				switch(temp) {
					case 0:
						trr[0]+=1;
						break;
					case 1:
						trr[1]+=1;
						break;
					case 2:
						trr[2]+=1;
						break;
					case 3:
						trr[3]+=1;
						break;
					case 4:
						trr[4]+=1;
						break;
					case 5:
						trr[5]+=1;
						break;
					case 6:
						trr[6]+=1;
						break;
					case 7:
						trr[7]+=1;
						break;
					case 8:
						trr[8]+=1;
						break;
					case 9:
						trr[9]+=1;
						break;
				}
			}
		}
		for(int k=0; k<10; k++) {
			if(trr[k]!=0)
				System.out.printf("%d : %d개\n", k, trr[k]);
		}

		
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int arr[] = new int[100];
		int i=0;
		while (true) {
			int x=scanner.nextInt();
			arr[i]=x;
			if(arr[i]==0) break;
			i++;
		}

		countT(arr);
	}
}
