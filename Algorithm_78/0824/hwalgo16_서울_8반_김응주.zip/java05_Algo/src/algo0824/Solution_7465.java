package algo0824;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.StringTokenizer;



public class Solution_7465 {

	static HashSet<Integer> set;
	static int[] parents; // 부모원소를 관리(트리처럼 사용)
	
	private static void make(int N) {
		// 모든 원소를 자신을 대표자로 만듦
		for (int i = 1; i <= N; i++) {
			parents[i] = i;
		}
	}
	// a가 속한 집합의 대표자 찾기
	private static int find(int a) {
		if(a==parents[a]) return a; // 자신이 대표자.
		return parents[a] = find(parents[a]); // 자신이 속합 집합의 대표자를 자신의 부모로 : path compression
	}

	// 두 원소를 하나의 집합으로 합치기(대표자를 이용해서 합침)
	private static boolean union(int a, int b) {
		int aRoot = find(a);
		int bRoot = find(b);
		if(aRoot == bRoot) return false; // 이미 같은 집합으로 합치지 않음
		
		parents[bRoot] = aRoot;
		return true;
	}
	
	public static void main(String[] args) throws IOException {
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer str = null;
		StringBuilder sb = new StringBuilder();
		int TestCase = Integer.parseInt(bfr.readLine());
		for(int i=1; i<=TestCase; i++) {
			set=new HashSet<>();
			str=new StringTokenizer(bfr.readLine());
			int N=Integer.parseInt(str.nextToken());
			int M=Integer.parseInt(str.nextToken());
			parents= new int[N+1];

			make(N);
			for(int k=0; k<M; k++) {
				str=new StringTokenizer(bfr.readLine());
				int a=Integer.parseInt(str.nextToken());
				int b=Integer.parseInt(str.nextToken());
				union(a,b);
			}
			for(int k=1; k<=N; k++) {
				set.add(find(k));
			}
			sb.append("#"+i+" ").append(set.size()+"\n");
		}
		System.out.println(sb);
		
		// make set
		
		
	}

}
