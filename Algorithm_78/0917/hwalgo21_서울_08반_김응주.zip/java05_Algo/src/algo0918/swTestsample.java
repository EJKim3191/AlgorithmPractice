package algo0918;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class swTestsample {
	public static int T, N;
	public static int[][] map;
	public static ArrayList<Point> arr = new ArrayList<>();
	public static int[] dx = { 0, 0, 1, -1 };
	public static int[] dy = { 1, -1, 0, 0 };
	public static int Core, Line; 
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer str = null;
		StringBuilder sb = new StringBuilder();

		T = Integer.parseInt(bfr.readLine());
		for (int testCase = 1; testCase <= T; testCase++) {
			arr.clear();
			N = Integer.parseInt(bfr.readLine());
			map = new int[N][N];
			for (int i = 0; i < N; i++) {
				str = new StringTokenizer(bfr.readLine());
				for (int j = 0; j < N; j++) {
					map[i][j] = Integer.parseInt(str.nextToken());
					if(i!=0 && j!=0 && map[i][j]==1) arr.add(new Point(i, j));
					
				}
			}
			Core=0;
			Line=0;
			// 테두리 무시
			dfs(0, 0, 0);
			
			sb.append("#").append(testCase).append(" ").append(Line).append("\n");
		}
		System.out.print(sb);
	}	
	public static void dfs(int depth, int core, int line) {
		if(depth==arr.size()) {
			//코어, 라인길이 조건
			if(core>Core) {
				Core=core;
				Line=line;
			}
			else if(core==Core) {
				if(Line>line) Line=line;
			}
			return;
		}
		for(int i=0; i<4; i++) {
			if(isTrue(arr.get(depth), i)) {
				int length = makeLine(arr.get(depth), i, 2);
				dfs(depth+1, core+1, length+line);
				makeLine(arr.get(depth), i, 0);
			}
		}
		dfs(depth+1, core, line);
	}
	public static boolean isTrue(Point p, int dir) {
		int x=p.x+dx[dir];
		int y=p.y+dy[dir];
		
		while(x>=0 && y>=0 && x<N && y<N) {
			if(map[y][x]!=0) return false;
			x+=dx[dir];
			y+=dy[dir];
		}
		return true;
	}
	public static int makeLine(Point p, int dir, int num) {
		int length=0;
		int x=p.x+dx[dir];
		int y=p.y+dy[dir];
		while(x>=0 && y>=0 && x<N && y<N) {
			map[y][x]=num;
			length+=1;
			x+=dx[dir];
			y+=dy[dir];
		}
		return length;
		
	}
	static class Point{
		int x; int y;

		/**
		 * @param x
		 * @param y
		 */
		public Point(int y, int x) {
			super();
			this.x = x;
			this.y = y;
		}
		
	}
}
