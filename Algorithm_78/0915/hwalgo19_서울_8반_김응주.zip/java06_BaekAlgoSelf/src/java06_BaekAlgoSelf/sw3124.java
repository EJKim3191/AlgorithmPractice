package java06_BaekAlgoSelf;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.StringTokenizer;

public class sw3124 {
	public static int T, V, E;
	public static ArrayList<Edge>[] arr;
	public static PriorityQueue<Edge> p = new PriorityQueue<>();
	public static Queue<Integer> q = new LinkedList<>();
	public static boolean[] visited;
	public static int[] distance;

	public static class Edge implements Comparable<Edge> {
		int start;
		int end;
		int value;

		public Edge(int start, int end, int value) {
			super();
			this.start = start;
			this.end = end;
			this.value = value;
		}

		@Override
		public int compareTo(Edge o) {
			// TODO Auto-generated method stub
			return Long.compare(this.value, o.value);
		}

	}

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer str = null;
		StringBuilder sb = new StringBuilder();
		T = Integer.parseInt(bfr.readLine());
		for(int k=1; k<=T; k++) {
			str = new StringTokenizer(bfr.readLine());
			V = Integer.parseInt(str.nextToken());
			E = Integer.parseInt(str.nextToken());
			visited = new boolean[V + 1];
			distance = new int[V + 1];
			arr = new ArrayList[V + 1];
			for (int i = 0; i <= V; i++) {
				arr[i] = new ArrayList<>();
			}
			
			for (int i = 0; i < E; i++) {
				str = new StringTokenizer(bfr.readLine());
				
				int A = Integer.parseInt(str.nextToken());
				int B = Integer.parseInt(str.nextToken());
				int C = Integer.parseInt(str.nextToken());
				
				arr[A].add(new Edge(A, B, C));
				arr[B].add(new Edge(B, A, C));
				
			}
			long result = 0;
			q.add(1);
			while (!q.isEmpty()) {
				int now = q.poll();
				visited[now] = true;
				
				for (Edge edge : arr[now]) {
					if (!visited[edge.end]) {
						p.add(edge);
					}
				}
				while (!p.isEmpty()) {
					Edge edge = p.poll();
					if (!visited[edge.end]) {
						q.add(edge.end);
						visited[edge.end] = true;
						result += edge.value;
						break;
					}
				}
			}
			sb.append("#").append(k).append(" ").append(result).append("\n");
		}
		System.out.print(sb);

	}
}
