package algo0820;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Stack;
import java.util.StringTokenizer;

public class hwalgo14_서울_8반_김응주 {
	public static Stack<Character> stack;
	public static Stack<Integer> calc;
	public static char[] input;
	public static ArrayList<Character> output;
	public static int testCase = 10;
	public static int length;
	public static StringBuilder sb = new StringBuilder();

	public static void main(String[] args) throws NumberFormatException, IOException {
		// 후위 표기식
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer str = null;
		for (int i = 0; i < 10; i++) {
			stack = new Stack<>();
			calc = new Stack<>();
			length = Integer.parseInt(bfr.readLine());
			String temp = bfr.readLine();
			input = new char[length];
			output = new ArrayList<>();
			for (int j = 0; j < length; j++) {
				input[j] = temp.charAt(j);
			}
			sb.append("#").append(i+1).append(" ");
			postFix(input);
		}
		System.out.println(sb);
	}
	public static void calc(ArrayList<Character> output) {
		int temp;

		for(int k=0; k<output.size(); k++) {
			if(output.get(k).equals('*')) {
				temp=calc.pop()*calc.pop();
				calc.add(temp);
			}
			else if(output.get(k).equals('+')) {
				temp=calc.pop()+calc.pop();
				calc.add(temp);
			}
			else {
				calc.add(output.get(k)-'0');
			}
		}
		sb.append(calc.pop()).append("\n");


	}
	// 곱하기가 붙으면 괄호, 괄호안의 기호는 뒤로
	// 더하기가 붙으면 바로뒤
	public static void postFix(char[] input) {
		for(int i=0; i<length; i++) {
			if(input[i]=='+') {
				while(!stack.isEmpty()) {
					output.add(stack.pop());
				}
				stack.add(input[i]);
			}
			else if(input[i]=='*') {
				while(!stack.isEmpty() && stack.peek()!='+') {
					output.add(stack.pop());
				}
				stack.add(input[i]);
			}
			else {
				output.add(input[i]);
			}
		}
		while(!stack.isEmpty()) {
			output.add(stack.pop());
			
		}
		calc(output);

	}
}
