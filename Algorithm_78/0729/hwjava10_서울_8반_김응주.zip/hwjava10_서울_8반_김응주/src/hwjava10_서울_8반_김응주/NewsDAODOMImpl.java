package hwjava10_서울_8반_김응주;

import java.util.List;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class NewsDAODOMImpl implements INewsDAO {
	//private final File xml = new File("XMLfile/Section902.xml");//주석처리 필요
	private List<News> list = new ArrayList<>();
	@Override
	public List<News> getNewsList(String url){//url로 바꿔줘야함
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			
			Document doc = builder.parse(url);
			
			Element root=doc.getDocumentElement();
			connectNews(root);
		}catch (IOException | ParserConfigurationException | SAXException e) {
            e.printStackTrace();
		}
		return list;
	}
	
	private void connectNews(Element root) {
		
		NodeList news = root.getElementsByTagName("item");
		for(int i = 0; i< news.getLength(); i++) {
			Node child = news.item(i);
			list.add(search(child));
		}
	}
	@Override
	public News search(Node node) {
		News news = new News();
		
		NodeList subNodes = node.getChildNodes();
		for(int j = 0; j < subNodes.getLength(); j++) {
			Node sub = subNodes.item(j);
			if(sub.getNodeName().equals("title")) {
				news.setTitle(sub.getTextContent());
			}
			else if(sub.getNodeName().equals("description")) {
				news.setDesc(sub.getTextContent());
			}
			else if(sub.getNodeName().equals("link")) {
				news.setDesc(sub.getTextContent());
			}
		}
		return news;
	}







}
