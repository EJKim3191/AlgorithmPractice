package hwjava10_서울_8반_김응주;

import java.util.List;

import javax.xml.soap.Node;

public interface INewsDAO {


	List<News> getNewsList(String url);

	News search(org.w3c.dom.Node node);
}
