package hwjava10_서울_8반_김응주;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.soap.Node;
import javax.xml.stream.events.StartElement;

import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.Attributes;
import org.xml.sax.HandlerBase;
import org.xml.sax.SAXException;







public class NewsDAOSAXImpl implements INewsDAO{
	private static final HandlerBase SAXHandler = null;
	private List<News> list = new ArrayList<>();
    // 현재 파싱하고 있는 대상 객체
    private News current;
    // 방금 읽은 텍스트 내용
    private String content;

	@SuppressWarnings("unused")
	private void connectNews(Element root) {
		NodeList news = root.getElementsByTagName("item");
		for(int i = 0; i< news.getLength(); i++) {
			org.w3c.dom.Node child = news.item(i);//
			list.add(search(child));
		}
		
	}
	public class SAXHandler{
		String b;
		boolean flag;
		News n;
		
	    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
	        // 방금 읽은 태그가 student라면 --> 새로운 Student 생성
	        if (qName.equals("dailyBoxOffice")) {
	            n = new News();
	        }
	    }
	    public void characters(char[] ch, int start, int length) throws SAXException {
	        this.b = new String(ch, start, length);
	    }

	    public void endElement(String uri, String localName, String qName) throws SAXException {
	        if (qName.equals("dailyBoxOffice")) {
	            list.add(current);
	            n = null;
	        } else if (qName.equals("title")) {
	            n.setTitle(current.getTitle());
	        } else if (qName.equals("desc")) {
	            n.setDesc(current.getDesc());
	        } else if (qName.equals("link")) {
	            n.setLink(current.getLink());
	 
	        }
	    }
	}

	@Override
	public List<News> getNewsList(String url) {
        // TODO: SAXParser를 구성하고 boxoffice.xml을 파싱하시오.
        try {
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser parser = factory.newSAXParser();
            parser.parse(url, SAXHandler);// 오류 why?
        } catch (IOException | SAXException | ParserConfigurationException e) {
            e.printStackTrace();
        }
        // END:
        return list;

	}

	@Override
	public News search(org.w3c.dom.Node node) {
		// TODO Auto-generated method stub
		return null;
	}

}
