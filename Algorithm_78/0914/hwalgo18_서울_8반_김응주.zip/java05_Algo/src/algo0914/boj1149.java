package algo0914;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class boj1149 {
	public static int N;
	public static int[][] d;
	public static int[][] price;

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer str = null;

		N = Integer.parseInt(bfr.readLine());
		d = new int[N + 1][4];
		price = new int[N + 1][4];
		for (int i = 1; i < N + 1; i++) {
			str = new StringTokenizer(bfr.readLine());
			for (int j = 1; j < 4; j++) {
				d[i][j] = Integer.parseInt(str.nextToken());
			}
		}
		
		price[1][1]=d[1][1];
		price[1][2]=d[1][2];
		price[1][3]=d[1][3];
		
		for (int i = 2; i < N + 1; i++) {
			price[i][1] = Math.min(price[i - 1][2], price[i - 1][3]) + d[i][1];
			price[i][2] = Math.min(price[i - 1][1], price[i - 1][3]) + d[i][2];
			price[i][3] = Math.min(price[i - 1][1], price[i - 1][2]) + d[i][3];
		}
		price[N][0] = Math.min(price[N][1], Math.min(price[N][2], price[N][3]));
		
		System.out.println(price[N][0]);
	}
}
