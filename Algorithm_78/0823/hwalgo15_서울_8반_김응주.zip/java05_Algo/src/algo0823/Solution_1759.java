package algo0823;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class Solution_1759 {
	public static int L;
	public static int C;
	public static ArrayList<Character> arr = new ArrayList<>();
	public static char[] output;
	public static boolean flag;
	static StringBuilder sb= new StringBuilder();
	public static void main(String[] args) throws IOException {
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer str = null;
		
		str = new StringTokenizer(bfr.readLine());
		L = Integer.parseInt(str.nextToken());
		C = Integer.parseInt(str.nextToken());
		output = new char[L];
		flag = false;
		str = new StringTokenizer(bfr.readLine());
		for (int i = 0; i < C; i++) {
			arr.add(str.nextToken().charAt(0));
		}
		arr.sort(null);

		boolean[] visited = new boolean[C];
		permu(visited, 0, 0);
		System.out.print(sb);
	}

	public static void permu(boolean[] visited, int depth, int current) {
		if (depth == L) {
			int mo=0;
			int ja=0;
			for (int i = 0; i < L; i++) {
				if (output[i]=='a' || output[i]=='e' || output[i]=='i' || output[i]=='o'
						|| output[i]=='u') mo+=1;
				else ja+=1;
			}
			if(ja>=2 && mo>=1) {				
				for (int j = 0; j < L; j++) {
					sb.append(output[j]);
				}
				sb.append("\n");
			}
			
			return;
		}
		for (int i = current; i < C; i++) {
			if (visited[i] != true) {
				visited[i] = true;
				output[depth] = arr.get(i);
				permu(visited, depth + 1, i);
				visited[i] = false;

			}
		}
	}
}
