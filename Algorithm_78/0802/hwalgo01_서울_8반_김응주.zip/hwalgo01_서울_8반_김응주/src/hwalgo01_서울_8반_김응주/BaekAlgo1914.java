package hwalgo01_서울_8반_김응주;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.math.BigInteger;

public class BaekAlgo1914 {
	//public static StringBuilder str = new StringBuilder();
		public static BufferedWriter str = new BufferedWriter(new OutputStreamWriter(System.out));
		
		public static void main(String[] args) throws IOException {
			BufferedReader scn = new BufferedReader(new InputStreamReader(System.in));
			//Scanner scn = new Scanner(System.in);
			//int n = scn.nextInt();
			int n = Integer.parseInt(scn.readLine());
			//공비 수열 ---> 2^n-1
			BigInteger Bn= new BigInteger("2").pow(n).subtract(BigInteger.ONE);
			
			str.append(Bn + "\n");
			//str.write(answ + "\n");
			//System.out.printf("%d\n", answ);
			if(n<=20) recursive(n, 1, 2, 3);
			//System.out.println(str);
			str.flush();
			str.close();
		}
		private static BigInteger BigInteger(String string) {
			// TODO Auto-generated method stub
			return null;
		}
		public static void recursive(int n, int start, int mid, int end) throws IOException {
			if(n==1) {
				str.write(start+ " "+ end + "\n");
				//str.append(start+ " "+ end + "\n");
				//System.out.printf("%d %d\n", start, end);
				return;

			}
			//n-1 덩어리 옮기기
			recursive(n-1, start, end, mid);
			
			//n덩어리 옮기기
			str.write(start+ " "+ end + "\n");
			//str.append(start + " " + end + "\n");
			//System.out.printf("%d %d\n", start, end);

			//n-1덩어리 옮기기
			recursive(n-1, mid, start, end);
		}
		
}
