package algo1006;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class sw4014 {
	public static int T, N, X;
	public static int map[][];
	public static int count;
	public static boolean[][] R, C;

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer str = null;
		StringBuilder sb = new StringBuilder();

		T = Integer.parseInt(bfr.readLine());
		for (int testCase = 1; testCase <= T; testCase++) {
			str = new StringTokenizer(bfr.readLine());
			N = Integer.parseInt(str.nextToken());
			X = Integer.parseInt(str.nextToken());
			map = new int[N][N];
			C = new boolean[N][N];
			R = new boolean[N][N];
			for (int i = 0; i < N; i++) {
				str = new StringTokenizer(bfr.readLine());
				for (int j = 0; j < N; j++) {
					map[i][j] = Integer.parseInt(str.nextToken());
				}
			}
			count = 0;
			isCTrue();
			isRTrue();
			sb.append("#").append(testCase).append(" ").append(count).append("\n");
		}
		System.out.println(sb);
	}

	public static void isCTrue() {
		for (int i = 0; i < N; i++) {
			boolean isTrue = true;
			for (int j = 0; j < N - 1; j++) {
				if (map[i][j] == map[i][j + 1]) {
					continue;
				}
				if (map[i][j] > map[i][j + 1]) {
					if (map[i][j] - map[i][j + 1] > 1) {
						isTrue = false;
						break;
					}
					if (j + X >= N) {
						isTrue = false;
						break;
					}

					for (int k = j + 1; k <= j + X; k++) {
						if (map[i][j + 1] != map[i][k]) {
							isTrue = false;
							break;
						}
						if (C[i][k]) {
							isTrue = false;
							break;
						}
					}
					if (!isTrue)
						break;
					for (int k = j + 1; k <= j + X; k++) {
						C[i][k] = true;
					}
				} else if (map[i][j] < map[i][j + 1]) {
					if (map[i][j + 1] - map[i][j] > 1) {
						isTrue = false;
						break;
					}

					if (j + 1 - X < 0) {
						isTrue = false;
						break;
					}

					for (int k = j; k >= j + 1 - X; k--) {
						if (map[i][j] != map[i][k]) {
							isTrue = false;
							break;
						}
						if (C[i][k]) {
							isTrue = false;
							break;
						}
					}
					if (!isTrue)
						break;
					for (int k = j; k >= j + 1 - X; k--) {
						C[i][k] = true;
					}
				}
			}
			if (isTrue)
				count++;
		}
	}

	public static void isRTrue() {
		for (int j = 0; j < N; j++) {
			boolean isTrue = true;
			for (int i = 0; i < N - 1; i++) {
				if (map[i][j] == map[i + 1][j]) {
					continue;
				}
				if (map[i][j] > map[i + 1][j]) {
					if (map[i][j] - map[i + 1][j] > 1) {
						isTrue = false;
						break;
					}
					if (i + X >= N) {
						isTrue = false;
						break;
					}

					for (int k = i + 1; k <= i + X; k++) {
						if (map[i + 1][j] != map[k][j]) {
							isTrue = false;
							break;
						}
						if (R[k][j]) {
							isTrue = false;
							break;
						}
					}
					if (!isTrue)
						break;
					for (int k = i + 1; k <= i + X; k++) {
						R[k][j] = true;
					}
				} else if (map[i][j] < map[i + 1][j]) {
					if (map[i + 1][j] - map[i][j] > 1) {
						isTrue = false;
						break;
					}
					if (i + 1 - X < 0) {
						isTrue = false;
						break;
					}
					for (int k = i; k >= i + 1 - X; k--) {
						if (map[i][j] != map[k][j]) {
							isTrue = false;
							break;
						}
						if (R[k][j]) {
							isTrue = false;
							break;
						}
					}
					if (!isTrue)
						break;
					for (int k = i; k >= i + 1 - X; k--) {
						R[k][j] = true;
					}
				}

			}

			if (isTrue)
				count++;
		}
	}
}
