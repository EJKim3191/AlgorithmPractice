use ssafy;

create table product(
	pid int(5) not null,
    pname char(20),
    price int(20),
    qty int(20),
    primary key(pid)
);

create table customer(
	cnum int(5) not null,
    cname char(20),
    address char(100),
    phoneNumber1 int(10),
    phoneNumber2 int(10),
    primary key(cnum)
);

create table orders(
	orderNum int(5) not null,
    orderPrice int(3),
    isPayed boolean,
    isDelivered boolean,
    pid int(5),
    primary key(orderNum)
);
alter table orders
add constraint pid
foreign key(pid)
references product(pid);