package algo0916;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class boj9205 {
	public static int t;
	public static int n;
	public static boolean[][] canG;

	public static ArrayList<Point> conv= new ArrayList<>();
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer str = null;
		StringBuilder sb = new StringBuilder();
		
		t=Integer.parseInt(bfr.readLine());
		for(int testCase=0; testCase<t; testCase++) {
			n=Integer.parseInt(bfr.readLine());
			canG= new boolean[n+2][n+2];
			conv.clear();
			str=new StringTokenizer(bfr.readLine());
			conv.add(new Point(Integer.parseInt(str.nextToken()), Integer.parseInt(str.nextToken())));
			for(int k=0; k<n; k++) {
				str=new StringTokenizer(bfr.readLine());
				conv.add(new Point(Integer.parseInt(str.nextToken()), Integer.parseInt(str.nextToken())));
			}
			str=new StringTokenizer(bfr.readLine());
			conv.add(new Point(Integer.parseInt(str.nextToken()), Integer.parseInt(str.nextToken())));
			canGo();
			floyed();

			if(canG[0][n+1]==false) sb.append("sad").append("\n");
			else sb.append("happy").append("\n");
		}
		System.out.print(sb);
	}
	public static void canGo() {
		for(int i=0; i<n+2; i++) {
			for(int j=0; j<n+2; j++) {
				if(Math.abs(conv.get(i).x-conv.get(j).x)+Math.abs(conv.get(i).y-conv.get(j).y)<=1000) canG[i][j]=true;
				else canG[i][j]=false;
			}
		}
	}
	public static void floyed() {
		//k는 중간 지점---> only convinient store
		for(int k=0; k<n+2; k++) {
			for(int i=0; i<n+2; i++) {
				for(int j=0; j<n+2; j++) {
					if(canG[i][k] && canG[k][j]) {
						canG[i][j]=true;
					}
				}
			}
		}
	}
	
	
	static class Point{
		int x; int y;
		/**
		 * @param x
		 * @param y
		 */
		public Point(int x, int y) {
			super();
			this.x = x;
			this.y = y;
		}
	}
}
