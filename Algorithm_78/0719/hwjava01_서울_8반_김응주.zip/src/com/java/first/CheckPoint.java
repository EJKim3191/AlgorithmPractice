package com.java.first;

import java.util.Scanner;

public class CheckPoint {
	public static int fat(int num1, int num2) { //num1 몸무개, num2 키, return 비만수치
		int fatN= num1+100-num2;
		return fatN;
	}
	public static void main(String[] args) {
		//비만수치 공식 : 몸무게 + 100 - 키
		int num1, num2;
		int result;
		
		Scanner scr = new Scanner(System.in);
		num1 = scr.nextInt();
		num2 = scr.nextInt();
		
		result = fat(num2,num1);
		System.out.println("비만수치는 "+result+"입니다.");
		if (result>0) System.out.println("당신은 비만이군요");
	}
}
