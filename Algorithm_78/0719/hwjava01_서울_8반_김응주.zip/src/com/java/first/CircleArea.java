package com.java.first;

public class CircleArea {
	public static double areaC(double a) {
		return a*a*Math.PI;
	}
	public static void main(String[] args) {
		double a = areaC(5.0);;

		System.out.println("반지름이 5cm인 원의 넓이는"+ a + "Cm2입니다.");
	}
}
