package com.java.first;

import java.util.Scanner;

public class Compute {
	public static int multT(int num1, int num2) {
		return num1*num2;
	}
	public static int divT(int num1, int num2) {
		return num1/num2;
	}
	public static void main(String[] args) {
		int a, b;
		Scanner scr = new Scanner(System.in);
		a=scr.nextInt();
		b=scr.nextInt();
		System.out.printf("곱=%d", multT(a,b));
		System.out.println();
		System.out.printf("몫=%d", divT(a,b));
		scr.close();
		scr=null;
	}
}
