package hwalgo06_서울_8반_김응주;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Stack;
import java.util.StringTokenizer;

public class Solution_2563 {
	
	/*
	 * 조합 풀이 but 시간안에 백준 통과 x
	 * 검은색 종이의 넓이 구하기 검은색 종이 1개 넓이 = 100 검은색 종이 N개 넓이 = N * 100 - 곂친곳
	 */

	private static int N;
	private static int dx[];
	private static int dy[];
	private static int overlap;
	private static boolean sel[];

	private static Stack<Integer> temp = new Stack<>();

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer str = null;

		N = Integer.parseInt(bfr.readLine());
		dx = new int[N];
		dy = new int[N];
		sel = new boolean[N];
		for (int i = 0; i < N; i++) {
			str = new StringTokenizer(bfr.readLine());
			dx[i] = Integer.parseInt(str.nextToken());
			dy[i] = Integer.parseInt(str.nextToken());
		}
		overlap = 0;
		comb(0, 0);
		System.out.println(N*100-overlap);
	}

	public static void comb(int num, int isSel) {

		if (isSel == 2) {
			for(int i=0; i<N; i++) {
				if(sel[i]) {
					temp.add(i);
				}
			}
			int a=temp.pop(); int b=temp.pop();
			if (Math.abs(dx[a] - dx[b]) < 10 && Math.abs(dy[a] - dy[b]) < 10) { // 곂치는 조건
				overlap += (10 - Math.abs(dx[a] - dx[b])) * (10 - Math.abs(dy[a] - dy[b]));
				// System.out.println(overlap);
				return;
			} 
		}
		if(num==N) return;
		sel[num]=true;
		comb(num + 1, isSel + 1);
		sel[num]=false;
		comb(num + 1, isSel);
	}

}
