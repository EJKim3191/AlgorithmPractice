package hwalgo06_서울_8반_김응주;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Solution_2563_2 {
	/*
	 * 
	 * 백준 통과 o 매우 단순 풀이
	 * 
	 */
	private static int N;
	private static int dx[];
	private static int dy[];
	private static int map[][];
	private static int sum;
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer str = null;

		N = Integer.parseInt(bfr.readLine());
		dx = new int[N];
		dy = new int[N];
		map = new int [100][100];
		sum=0;
		for (int i = 0; i < N; i++) {
			str = new StringTokenizer(bfr.readLine());
			dx[i] = Integer.parseInt(str.nextToken());
			dy[i] = Integer.parseInt(str.nextToken());
		}
		for(int i=0; i<N; i++) {
			for(int y=0; y<10; y++) {
				for(int x=0; x<10; x++) {
					map[dy[i]+y][dx[i]+x]+=1;					
				}
			}
		}
		for(int y=0; y<100; y++) {
			for(int x=0; x<100; x++) {
				if(map[y][x]>=1) {
					sum+=1;
				}
			}
		}
		System.out.println(sum);

	}
}
