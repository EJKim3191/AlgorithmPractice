package hwalgo02_서울_8반_김응주;

import java.util.Scanner;

public class Solution6 {
	static int N;
	static int dal[][];
	static boolean isEmpty[][];
	static int dx = 0, dy = 0;
	static int num = 1;
	static boolean flag = true;
	static int testNow = 1;
	public static void dalMake() {
		// 오른쪽
		while (dx + 1 < N && isEmpty[dy][dx + 1] != true) {
			dx++;
			dal[dy][dx] = num;
			isEmpty[dy][dx] = true;
			num++;
		}
		// 아래
		while (dy + 1 < N && isEmpty[dy + 1][dx] != true) {
			dy++;
			dal[dy][dx] = num;
			isEmpty[dy][dx] = true;
			num++;
		}
		// 왼쪽
		while (dx - 1 >= 0 && isEmpty[dy][dx - 1] != true) {
			dx--;
			dal[dy][dx] = num;
			isEmpty[dy][dx] = true;
			num++;
		}
		// 위
		while (dy - 1 >= 0 && isEmpty[dy - 1][dx] != true) {
			dy--;
			dal[dy][dx] = num;
			isEmpty[dy][dx] = true;
			num++;
		}

		if (dx + 1 < N && isEmpty[dy][dx + 1] != true && dy + 1 < N && isEmpty[dy + 1][dx] != true && dx - 1 > 0
				&& isEmpty[dy][dx - 1] != true && dy - 1 > 0 && isEmpty[dy - 1][dx] != true)
			return;

	}

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		int tc = scn.nextInt();
		for (int a = 0; a < tc; a++) {
			N = scn.nextInt();
			dal = new int[N][N];
			isEmpty = new boolean[N][N];
			dal[dy][dx] = 1;
			num += 1;
			isEmpty[dy][dx] = true;
			if (N % 2 == 0) {
				for (int k = 0; k < N / 2; k++)
					dalMake();
			} else {
				for (int k = 0; k < (N + 1) / 2; k++)
					dalMake();
			}
			System.out.printf("#%d\n", testNow);
			testNow+=1;
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					System.out.printf("%d ", dal[i][j]);
				}
				System.out.println();
			}
			num=1;
			dx = 0; dy = 0;
		}
	}

}
