package algo0923;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
 
public class jo1681 {
    public static int[][] arr;
    public static boolean[] visited;
    public static int N;
    public static int sum;
    public static int min;
    
    public static void main(String[] args) throws NumberFormatException, IOException {
        BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
        StringTokenizer str = null;
        N = Integer.parseInt(bfr.readLine());
        arr = new int[N][N];
        
        for(int i = 0; i<N; i++) {
            str = new StringTokenizer(bfr.readLine());
            for(int j = 0; j<N; j++) {
                arr[i][j]=Integer.parseInt(str.nextToken());
            }
        }
        min = 999999;
        visited = new boolean[N];
        visited[0]=true;
        dfs(0,0,0);
        System.out.println(min);
    }
    public static void dfs(int from, int to, int cost) {
		if(to == N-1) {
			if(arr[from][0] == 0) return;
			cost += arr[from][0];
			min = Math.min(cost, min);
			return;
		}
		if(cost>min) return;
		for(int i = 0 ; i < N ; i++) {
			if(visited[i]) continue;
			if(arr[from][i] == 0) continue;
			visited[i] = true;
			dfs(i,to+1,cost+arr[from][i]);
			visited[i] = false;
		}
	}
}
