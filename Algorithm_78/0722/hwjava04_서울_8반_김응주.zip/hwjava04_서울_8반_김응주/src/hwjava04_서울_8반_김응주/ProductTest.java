package hwjava04_서울_8반_김응주;

import java.util.Scanner;

public class ProductTest {
	public static void main(String[] args) {
		//제품정보 저장
		TV tv = new TV("abc123", "스마트티비", 1340000, 30, 50, "LCD");
		
		Refrigerator re = new Refrigerator("134qwe", "스마트냉장고", 900000, 12, 50);

		//제품정보 출력
		System.out.println(tv.toString());
		System.out.println(re.toString());
	}
}
