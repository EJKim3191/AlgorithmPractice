package hwjava05_서울_8반_김응주;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Solution_9229 {
	public static int N;//과자봉지개수
	public static int M;//무게합 제한
	public static int snack[];
	public static int sum;
	public static int testCase;
	public static void calc(int idx, int weight, int cnt) {
		if(weight>M) return;
		if(cnt>3) {
			return;
		}
		if(cnt==2 && weight <= M) {
			sum=Math.max(weight, sum);
			return;
		}
		if(idx==N) return;
		calc(idx+1, weight+snack[idx], cnt+1);//들기
		calc(idx+1, weight, cnt);//안들기			
	}
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer str = null;
		StringBuilder sb = new StringBuilder();
		testCase = Integer.parseInt(bfr.readLine());
		for(int i=0; i<testCase; i++) {
			sum=-1;//sum 값  초기화
			
			str = new StringTokenizer(bfr.readLine());
			N=Integer.parseInt(str.nextToken());
			M=Integer.parseInt(str.nextToken());
			str = new StringTokenizer(bfr.readLine());
			snack= new int[N];
			
			for(int j=0; j<N; j++) {
				snack[j]=Integer.parseInt(str.nextToken());
			}
			calc(0,0,0);

			sb.append("#").append(i+1).append(" ").append(sum).append("\n");
			
		}
		System.out.println(sb);
	}
	
}
