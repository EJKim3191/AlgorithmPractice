package hwjava05_서울_8반_김응주;

public class ProductTest {
	public static void main(String[] args) {
		ProductMgr mgr = new ProductMgr();
		TV tv1 = new TV("abc123", "스마트티비", 1340000, 30, 50, "LCD");
		TV tv2 = new TV("b1a3c2", "브라운관티비", 324000, 59, 24, "브라운");
		
		Refrigerator re1 = new Refrigerator("134qwe", "스마트냉장고", 900000, 12, 50);
		Refrigerator re2 = new Refrigerator("aeew12", "2012 냉장고", 13000, 43, 40);
		//상품 정보 객체 배열 활용 저장
		mgr.saveInfo(tv1);
		mgr.saveInfo(tv2);
		mgr.saveInfo(re1);
		mgr.saveInfo(re2);
		
		System.out.println("--------------상품 정보 전체 검색 (출력)--------------");
		//상품 정보 전체 검색 (출력)
		mgr.search();
		System.out.println();
		
		System.out.println("--------------상품번호 상품 검색--------------");
		//상품번호 상품 검색
		mgr.searchByPid("123");//없는 번호 검색
		mgr.searchByPid("134qwe");//존재하는 번호 검색
		System.out.println();
		
		System.out.println("--------------상품 명으로 검색--------------");
		//상품 명으로 검색
		mgr.searchByName("똥칼라티비");
		mgr.searchByName("스마트티비");
		System.out.println();
		
		System.out.println("--------------TV정보만 검색--------------");
		mgr.searchByTv();
		System.out.println();
		
		System.out.println("--------------Refrigerator만 검색--------------");
		mgr.searchByRe();
		System.out.println();
		
		System.out.println("--------------상품번호로 상품 삭제--------------");
		mgr.deleteByPid("abc123");
		mgr.search();
		System.out.println();
		
		System.out.println("--------------전체 재고 상품 금액--------------");
		System.out.printf("전체 재고 상품 금액: %d", mgr.printAllPrice());
	}
}
