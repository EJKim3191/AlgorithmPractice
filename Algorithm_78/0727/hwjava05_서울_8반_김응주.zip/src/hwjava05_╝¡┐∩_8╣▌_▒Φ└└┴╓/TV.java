package hwjava05_서울_8반_김응주;

public class TV extends Product{
	public int MAX_SIZE=100;
	TV [] Tv = new TV[MAX_SIZE];

	
	private String pid; //제품 번호
	private String pname; //제품 이름
	private int price; // 가격
	private int pnum; // 수량
	private int pin; // 인치
	private String ptype; // 디스플레이 타입
	//constructor
	
	public TV(){
		
	}
	public TV(String pid, String pname, int price, int pnum, int pin,String ptype) {
		this.pid = pid;
		this.pname=pname;
		this.price=price;
		this.pnum=pnum;
		this.pin=pin;
		this.ptype=ptype;
	}
	//getter and setter
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getPnum() {
		return pnum;
	}
	public void setPnum(int pnum) {
		this.pnum = pnum;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public String getPtype() {
		return ptype;
	}
	public void setPtype(String ptype) {
		this.ptype = ptype;
	}
	


	//to string
	@Override
	public String toString() {
		return "TV [상품번호 = " + pid + ", 상품명 = " + pname + ", 가격 = " + price + ", 갯수 = " + pnum + ", 크기 = " + pin
				+ ", 종류 = " + ptype + "]";
	}
}
