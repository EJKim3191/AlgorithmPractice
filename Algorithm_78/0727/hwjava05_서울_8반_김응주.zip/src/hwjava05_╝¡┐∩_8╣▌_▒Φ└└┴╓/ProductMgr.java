package hwjava05_서울_8반_김응주;

public class ProductMgr {
	// 배열로 할당해야해

	int MAX_SIZE = 100;
	Product[] product = new Product[MAX_SIZE];
	int size = 0; // 현재 크기
	// public Product[] arr = {};

	public void saveInfo(Product prd) {// 상품정보를 객체 배열을 활용 저장

		if (prd instanceof TV) {// tv라면 tv에!
			if (size <= MAX_SIZE)
				product[size] = prd;// 들어오는 객체 저장
			size += 1;
		}

		else if (prd instanceof Refrigerator) {// 냉장고라면 냉장고에!
			if (size <= MAX_SIZE)
				product[size] = prd;// 들어오는 객체 저장
			size += 1;
		} else
			System.out.println("error!!");
		// 예외처리?

	}

	public void search() {// 상품정보 전체 검색?? 검색한다는 것이 전체 출력? 을 얘기하는 것 같다
		for (int i = 0; i < size; i++) {
			if (product[i] instanceof TV) {// tv라면 tv에!
				// System.out.println("foundTV");
				System.out.println(product[i].toString());
			} else if (product[i] instanceof Refrigerator) {// 냉장고라면 냉장고에!
				// System.out.println("foundRe");
				System.out.println(product[i].toString());
			} else
				System.out.println("error!!");

		}
		// 예외처리?
	}

	public void searchByPid(String pid) {// 상품번호 상품 검색
		boolean exsist = false;
		for (int i = 0; i < size; i++) {
			if (product[i] instanceof TV && ((TV) product[i]).getPid().equals(pid)) {
				System.out.println(product[i].toString());
				exsist = true;
			} else if (product[i] instanceof Refrigerator && ((Refrigerator) product[i]).getPid().equals(pid)) {
				System.out.println(product[i].toString());
				exsist = true;
			}

		}
		if (exsist == false)
			System.out.println("찾으시는 상품번호는 존재하지 않습니다.");
	}

	public void searchByName(String pname) {// 상품명 상품검색(부분검색가능)
		boolean exsist = false;
		for (int i = 0; i < size; i++) {
			if (product[i] instanceof TV && ((TV) product[i]).getPname().equals(pname)) {
				System.out.println(product[i].toString());
				exsist = true;
			} else if (product[i] instanceof Refrigerator && ((Refrigerator) product[i]).getPname().equals(pname)) {
				System.out.println(product[i].toString());
				exsist = true;
			}

		}
		if (exsist == false)
			System.out.println("찾으시는 상품명은 존재하지 않습니다.");
	}

	public void searchByTv() {// TV정보만 검색
		for (int i = 0; i < size; i++) {
			if (product[i] instanceof TV) {// tv라면 tv에!
				// System.out.println("foundTV");
				System.out.println(product[i].toString());
			}
		}

	}

	public void searchByRe() {// Re만 검색
		for (int i = 0; i < size; i++) {
			if (product[i] instanceof Refrigerator) {// 냉장고라면 냉장고에!
				// System.out.println("foundRe");
				System.out.println(product[i].toString());
			}
		}
	}

	public void deleteByPid(String pid) {// 상품번호로 상품 삭제
		boolean exsist = false;
		for (int i = 0; i < size; i++) {
			if (product[i] instanceof TV && ((TV) product[i]).getPid().equals(pid)) {
				product[i] = product[size - 1];
				product[size - 1] = null;
				size--;
				exsist = true;
			} else if (product[i] instanceof Refrigerator && ((Refrigerator) product[i]).getPid().equals(pid)) {
				product[i] = product[size - 1];
				product[size - 1] = null;
				size--;
				exsist = true;
			}

		}
		if (exsist == false)
			System.out.println("찾으시는 상품번호는 존재하지 않습니다.");
	}

	public int printAllPrice() {// 전체 재고 상품 금액 구하기
		int sum=0;

		for(int i= 0 ; i< size; i++) {
			if (product[i] instanceof TV) {
			sum +=(((TV) product[i]).getPnum()) * (((TV) product[i]).getPrice());
			}
			else if (product[i] instanceof Refrigerator){
			sum +=(((Refrigerator) product[i]).getPnum()) * (((Refrigerator) product[i]).getPrice());
			}
//			product[i]
//			
//			
//			if (product[i] instanceof TV) {// tv라면 tv에!
//				pn=((TV)product[i].getPnum());
//				pr=((TV)product[i].getPrice());
//				}
//	
//			else if (prd instanceof Refrigerator) {// 냉장고라면 냉장고에!
//				if (size <= MAX_SIZE)
//					product[size] = prd;// 들어오는 객체 저장
//				size += 1;
//				}
			}
		return sum;
	}
}
