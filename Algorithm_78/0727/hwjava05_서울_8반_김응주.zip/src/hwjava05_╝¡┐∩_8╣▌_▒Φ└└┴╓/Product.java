package hwjava05_서울_8반_김응주;

public class Product {
	
	int MAX_SIZE = 100;
	String pid;//상품번호
	String pname;//상품명
	int price;//가격
	int pnum;//갯수
	public Product[] product= new Product[MAX_SIZE];//프로덕트 배열--> 다담을 그릇

	
	
	public Product() {
		super();
	}
	
	public Product(String pid, String pname, int price, int pnum) {
		super();
		this.pid = pid;
		this.pname=pname;
		this.price=price;
		this.pnum=pnum;
		this.price=price;
	}



	@Override
	public String toString() {
		return "Product [pid=" + pid + ", pname=" + pname + ", price=" + price + ", pnum=" + pnum + "]";
	}

}
