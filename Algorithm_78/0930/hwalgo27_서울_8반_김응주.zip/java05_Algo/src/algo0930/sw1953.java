package algo0930;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class sw1953 {
	public static int T;
	public static int N, M, R, C, L;
	public static int[][] map;
	public static boolean[][] isAvailable;
	public static Queue<Point> q;
	public static int[] dx= {0,0,1,-1};
	public static int[] dy= {1,-1,0,0};
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer str = null;
		StringBuilder sb = new StringBuilder();

		T = Integer.parseInt(bfr.readLine());
		for (int testCase = 1; testCase <= T; testCase++) {
			str = new StringTokenizer(bfr.readLine());
			N = Integer.parseInt(str.nextToken()); // 세로
			M = Integer.parseInt(str.nextToken()); // 가로
			R = Integer.parseInt(str.nextToken()); // 맨홀세로
			C = Integer.parseInt(str.nextToken()); // 멘홀가로
			L = Integer.parseInt(str.nextToken()); // 탈출 후 시간

			map = new int[N][M];
			isAvailable= new boolean[N][M];
			
			for (int i = 0; i < N; i++) {
				str=new StringTokenizer(bfr.readLine());
				for (int j = 0; j < M; j++) {
					map[i][j]=Integer.parseInt(str.nextToken());
				}
			}
			int answer=0;
			answer=bfs(R,C);
			
			sb.append("#").append(testCase).append(" ").append(answer).append("\n");
		}
		System.out.println(sb);
	}
	//상하, 좌우로 갈수 있는 판단
	public static boolean canGo(int x, int y, int dx, int dy) {
		//인자값을 바탕으로 위아래인지, 양옆인지 판단 후 ----> 모양에 따라 판별하기
		//좌로이동
		if(map[y][x]==0 || map[dy][dx]==0) return false;
		if(x-dx>0) { 
			if(map[y][x]==1 || map[y][x]==3 || map[y][x]==6 || map[y][x]==7) {
				if(map[dy][dx]==1 || map[dy][dx]==3 || map[dy][dx]==4 || map[dy][dx]==5) {
					return true;
				}
			}
		}
		if(x-dx<0) {
			if(map[dy][dx]==1 || map[dy][dx]==3 || map[dy][dx]==6 || map[dy][dx]==7) {
				if(map[y][x]==1 || map[y][x]==3 || map[y][x]==4 || map[y][x]==5) {
					return true;
				}
			}
		}
		if(y-dy>0) {
			if(map[y][x]==1 || map[y][x]==2 || map[y][x]==4 || map[y][x]==7) {
				if(map[dy][dx]==1 || map[dy][dx]==2 || map[dy][dx]==5 || map[dy][dx]==6) {
					return true;
				}
			}
		}
		if(y-dy<0) {
			if(map[dy][dx]==1 || map[dy][dx]==2 || map[dy][dx]==4 || map[dy][dx]==7) {
				if(map[y][x]==1 || map[y][x]==2 || map[y][x]==5 || map[y][x]==6) {
					return true;
				}
			}
		}
		//우로이동
		return false;
	}
	public static int bfs(int y, int x) {
		q= new LinkedList<>();
		q.add(new Point(x, y, map[y][x], 1));
		isAvailable[y][x]=true;
		
		while(!q.isEmpty()) {
			Point temp=q.poll();
			
			if(temp.time==L) continue;
			for(int i=0; i<4; i++) {
				int hx=temp.x+dx[i];
				int hy=temp.y+dy[i];
				
				if(hx<0 || hx>=M || hy<0 || hy>=N) continue;
				if(isAvailable[hy][hx]==true) continue;
				if(!canGo(temp.x, temp.y, hx, hy)) continue;
				
				q.add(new Point(hx, hy, map[hy][hx], temp.time+1));
				isAvailable[hy][hx]=true;
			}
			
		}
		//값
		int count=0;
		for(int i=0; i<N; i++) {
			for(int j=0; j<M; j++) {
				if(isAvailable[i][j]) count+=1;
			}
		}
		return count;
	}
	static class Point{
		int x, y, shape, time;

		/**
		 * @param x
		 * @param y
		 * @param shape
		 */
		public Point(int x, int y, int shape, int time) {
			super();
			this.x = x;
			this.y = y;
			this.shape = shape;
			this.time = time;
		}
		
	}
}
