package hwalgo11_서울_8반_김응주;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Stack;
import java.util.StringTokenizer;

public class Solution_2493 {
	private static int towerH[]; //타워의 높이
	private static int tSaved[]; //수신된 곳
	private static int N; //탑의 수
	private static Stack<Integer> stack= new Stack<>();
	
	public static void shoot() {
		int curT;
		for(int i=N-1; i>=0; i--) {
			curT=towerH[i];
			while(!stack.isEmpty() && towerH[stack.peek()]<=curT) {
				tSaved[stack.pop()]=i+1;
			}
			stack.push(i);
//			for(int k=i-1; k>=0; k--) {
//				if(curT<=towerH[k]) {
//					tSaved[i]=k+1;
//					//System.out.println(tSaved[i]);
//					break;
//				}
//			}
			
		}
	}
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer str = null;
		StringBuilder sb = new StringBuilder();
		N = Integer.parseInt(bfr.readLine());
		towerH=new int[N];
		tSaved=new int[N];

		//String towers = bfr.readLine();
		str= new StringTokenizer(bfr.readLine());
		//System.out.println(towers.toString());

		for(int i=0; i<N; i++) {
			tSaved[i]=0;
			towerH[i]=Integer.parseInt(str.nextToken());
		}
		shoot();
		for(int i=0; i<N; i++) {
			sb.append(tSaved[i]).append(" ");
		}

		System.out.println(sb);
	}
}
