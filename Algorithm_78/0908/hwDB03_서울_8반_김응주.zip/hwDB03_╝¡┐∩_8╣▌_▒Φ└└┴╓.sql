use scott;

#1
select emp.ename 이름, emp.sal 급여, dept.dname 부서명
from emp
inner join dept 
on emp.deptno=dept.deptno;

#2
select dept.dname 부서명
from emp
inner join dept 
on emp.deptno=dept.deptno
where emp.ename='KING';

#3
select dept.dname, emp.ename 이름, emp.deptno 부서번호, dept.dname 부서명, emp.sal 급여
from emp
inner join dept 
on emp.deptno=dept.deptno;

#4 
select concat(a.ename, '의 매니저는', b.ename, '이다.') 관계도
from emp a join emp b
on a.mgr = b.empno;

#5
select emp.ename 이름, dept.dname 부서명, emp.sal 급여, emp.job 직무
from emp
inner join dept
on emp.deptno=dept.deptno
where emp.job=(select emp.job from emp where emp.ename='SCOTT');

#6
select emp.empno 사원번호,emp.ename 이름, emp.hiredate 입사일, emp.sal 급여, dept.dname 부서명
from emp
inner join dept
on emp.deptno=dept.deptno
where dept.dname=(select dept.dname from emp inner join dept on emp.deptno=dept.deptno where emp.ename='SCOTT');

#7
select emp.empno 사원번호, emp.ename 이름, dept.dname 부서명, emp.hiredate 입사일, dept.loc 지역, emp.sal 급여
from emp
inner join dept
on emp.deptno=dept.deptno
where emp.sal > (select avg(sal) from emp);

#8
select emp.empno 사원번호, emp.ename 이름, dept.dname 부서명, dept.loc 지역, emp.sal 급여
from emp
inner join dept
on emp.deptno=dept.deptno
where emp.job in (select emp.job from emp inner join dept on emp.deptno=dept.deptno where emp.deptno=30)
order by emp.sal desc;

#9 
select emp.empno 사원번호, emp.ename 이름, dept.dname 부서명, emp.hiredate 입사일, dept.loc 지역
from emp
inner join dept
on emp.deptno=dept.deptno
where emp.job not in (select emp.job from emp inner join dept on emp.deptno=dept.deptno where emp.deptno=30);

#10
select emp.empno 사원번호, emp.ename 이름, emp.sal 급여
from emp
where emp.sal in (select emp.sal from emp where emp.ename='KING' or emp.ename='JAMES');

#11
select empno, ename, sal
from emp
where sal > (select max(sal)from emp where deptno = 30);
       
#12
create index idx_emp_ename 
on emp(ename desc);

#13
select ename, sal
from emp
where year(hiredate) = (select year(hiredate) from emp where ename ='ALLEN');

#14
create view sumSal as 
select dept.dname 부서명, sum(emp.sal) 합계
from emp
inner join dept
on emp.deptno=dept.deptno
group by emp.deptno;
select *
from sumSal;

#15
select *
from sumSal
order by 합계 desc
limit 3;