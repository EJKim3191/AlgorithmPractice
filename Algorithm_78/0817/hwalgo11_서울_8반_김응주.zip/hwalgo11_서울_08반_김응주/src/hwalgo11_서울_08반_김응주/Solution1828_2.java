package hwalgo11_서울_08반_김응주;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.StringTokenizer;

public class Solution1828_2 {
	public static int N;
	public static ArrayList<chemical1> che;
	public static boolean[] used;
	public static int min;
	public static int max;
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer str = null;
		N=Integer.parseInt(bfr.readLine());
		che= new ArrayList<>();
		used= new boolean[N];

		//입력받기
		for(int i =0; i<N; i++) {
			str=new StringTokenizer(bfr.readLine());
			int a=Integer.parseInt(str.nextToken());
			int b=Integer.parseInt(str.nextToken());
			//최대 최소 받아놓기

			che.add(new chemical1(a,b));
		}
		
		int cnt=0;
		//정렬
		//최고온도 기준
		Collections.sort(che);
		//System.out.printf("%d %d %d\n",che.get(0).y, che.get(1).y, che.get(2).y);
		while(true) {
			if(che.isEmpty()) {
				break;
			}
			min=che.get(0).x;
			max=che.get(0).y;
			for(int i=1; i<che.size(); i++) {
				//System.out.println(che.size());
				if(min>che.get(i).y || max<che.get(i).x) {
					continue;
				}
				else {
					min=Math.max(min, che.get(i).x);
					max=Math.min(max, che.get(i).y);
					che.remove(i);
					i-=1;
				}
			}
			che.remove(0);

			cnt+=1;
			
		}
		System.out.println(cnt);
	}
}
class chemical1 implements Comparable<chemical1>{
	int y;
	int x; 
	/**
	 * @param x
	 * @param y
	 */
	public chemical1(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}
	@Override
	public int compareTo(chemical1 chemical) {
		// TODO Auto-generated method stub
		if(chemical.y < y) {
			return 1;
		}
		else if(chemical.y> y) {
			return -1;
		}
		return 0;
	}
	
}