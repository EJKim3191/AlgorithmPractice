package hwjava06_서울_8반_김응주;


public class Refrigerator extends Product{
	public int MAX_SIZE;
	Refrigerator[] Re = new Refrigerator[MAX_SIZE];
	public int size=0;
	
//	private String pid; //제품 번호
//	private String pname; //제품 이름
//	private int price; //가격
//	private int pnum; //수량
	private int psize; //용량
	
//	public Refrigerator(String pid, String pname, int price, int pnum, int psize) {
//		this.pid = pid;
//		this.pname=pname;
//		this.price=price;
//		this.pnum=pnum;
//		this.psize=psize;
//	}
	public Refrigerator() {

	}
	public Refrigerator(String pid, String pname, int price, int pnum, int psize) {
		super(pid, pname, price, pnum);
		this.psize=psize;
	}
	//getter setter	
//	public String getPid() {
//		return pid;
//	}
//	public void setPid(String pid) {
//		this.pid = pid;
//	}
//	public String getPname() {
//		return pname;
//	}
//	public void setPname(String pname) {
//		this.pname = pname;
//	}
//	public int getPrice() {
//		return price;
//	}
//	public void setPrice(int price) {
//		this.price = price;
//	}
//	public int getPnum() {
//		return pnum;
//	}
//	public void setPnum(int pnum) {
//		this.pnum = pnum;
//	}
	public int getPsize() {
		return psize;
	}
	public void setPsize(int psize) {
		this.psize = psize;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(super.toString());
		builder.append("|");
		builder.append(psize);
		
		return builder.toString();
	}

}
