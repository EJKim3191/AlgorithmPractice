package hwjava06_서울_8반_김응주;

public interface IproductMgr {
	void saveInfo(Product prd);
	Product[] search();
	Product searchByPid(String pid);
	Product[] searchByName(String pname);
	Product[] searchByTv();
	Product[] searchByRe();
	void deleteByPid(String pid);
	int printAllPrice();
	
}
