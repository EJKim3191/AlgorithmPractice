package hwjava06_서울_8반_김응주;

public class Product {
	
	int MAX_SIZE = 100;
	private String pid;//상품번호
	private String pname;//상품명
	
	public Product() {
		super();
	}
	
	public Product(String pid, String pname, int price, int pnum) {
		super();
		this.pid = pid;
		this.pname=pname;
		this.price=price;
		this.pnum=pnum;
		this.price=price;
	}
	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getPnum() {
		return pnum;
	}

	public void setPnum(int pnum) {
		this.pnum = pnum;
	}



	int price;//가격
	int pnum;//갯수
	public Product[] product= new Product[MAX_SIZE];//프로덕트 배열--> 다담을 그릇

	
	



	@Override
	public String toString() {
		return "Product [pid=" + pid + ", pname=" + pname + ", price=" + price + ", pnum=" + pnum + "]";
	}

}
