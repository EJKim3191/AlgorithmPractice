package hwjava06_서울_8반_김응주;

import java.util.ArrayList;
import java.util.List;




public class ProductMgr implements IproductMgr {
	// 배열로 할당해야해

	//int MAX_SIZE = 100;
	//Product[] product = new Product[MAX_SIZE];
	private List<Product> product = new ArrayList<Product>();
	private static IproductMgr instance = new ProductMgr();
	private ProductMgr() { // 외부에서 객체 생성을 하지 못하도록 접근 제어자를  private으로 만든 생성자
	}
	/**
	 * 내부에서 생성한 객체의 참조값을 반환한다.
	 * @return 생성된 객체의 참조값
	 */
	public static IproductMgr getInstance() {
		return instance;
	}

	private int sum;
	//int size = 0; // 현재 크기
	// public Product[] arr = {};
	@Override
	public void saveInfo(Product prd) {// 상품정보를 객체 배열을 활용 저장

//		if (prd instanceof TV) {// tv라면 tv에!
//			if (size <= MAX_SIZE)
//				product[size] = prd;// 들어오는 객체 저장
//			size += 1;
//		}
//
//		else if (prd instanceof Refrigerator) {// 냉장고라면 냉장고에!
//			if (size <= MAX_SIZE)
//				product[size] = prd;// 들어오는 객체 저장
//			size += 1;
//		} else
//			System.out.println("error!!");
		product.add(prd);
		// 예외처리?

	}
	@Override
	public Product[] search() {
		Product[] result = new Product[product.size()];
		return product.toArray(result);  
	}
	@Override
	public Product searchByPid(String pid) {
		//System.out.println(product.get(1).getPid());
		for (int i = 0; i < product.size(); ++i) {
			if (product.get(i).getPid().equals(pid)) {
				return product.get(i); 
			}
		}

		return null;
	}
	@Override
	public Product[] searchByName(String pname) {// 상품명 상품검색(부분검색가능)
//		boolean exsist = false;
//		for (int i = 0; i < size; i++) {
//			if (product[i] instanceof TV && ((TV) product[i]).getPname().equals(pname)) {
//				System.out.println(product[i].toString());
//				exsist = true;
//			} else if (product[i] instanceof Refrigerator && ((Refrigerator) product[i]).getPname().equals(pname)) {
//				System.out.println(product[i].toString());
//				exsist = true;
//			}
//
//		}
//		if (exsist == false)
//			System.out.println("찾으시는 상품명은 존재하지 않습니다.");
		//return product.stream().filter(i -> i.getPname().equals(pname)).toString();
//		ArrayList<Product> temp = new ArrayList<Product>();
//		for (Product product : product) {
//			if(product.getPname().contains(pname)) temp.add(product);
//		}
//		Product[] result = new Product[temp.size()];
//		return temp.toArray(result);
		
//////
		int count=0;
		for (int i = 0; i < product.size(); ++i) {
			//if (books[i].getTitle().contains(title)) ++count;
			if (product.get(i).getPname().toLowerCase().contains(pname.toLowerCase())) ++count;
		}
		
		Product[] result1 = new Product[count];
		int idx = 0;
		for (int i = 0; i < product.size(); ++i) {
			if (product.get(i).getPname().contains(pname)) {
				result1[idx++] = product.get(i);
			}
		}
		return result1; 
	}
	@Override
	public Product[] searchByTv() {// TV정보만 검색
		int count = 0;
		for (int i = 0; i < product.size(); ++i) {
			if (product.get(i) instanceof TV) ++count;
		}
		
		TV[] result = new TV[count];
		int idx = 0;
		for (int i = 0; i < product.size(); ++i) {
			if (product.get(i) instanceof TV) {
				result[idx++] = (TV)product.get(i);
			}
		}
		return result;
	}
	@Override
	public Product[] searchByRe() {// Re만 검색
//		for (int i = 0; i < size; i++) {
//			if (product[i] instanceof Refrigerator) {// 냉장고라면 냉장고에!
//				// System.out.println("foundRe");
//				System.out.println(product[i].toString());
//			}
//		}
//		return product.stream().filter(i -> i instanceof Refrigerator).toString();
		int count = 0;
		for (int i = 0; i < product.size(); ++i) {
			if (product.get(i) instanceof Refrigerator) ++count;
		}
		
		Refrigerator[] result = new Refrigerator[count];
		int idx = 0;
		for (int i = 0; i < product.size(); ++i) {
			if (product.get(i) instanceof Refrigerator) {
				result[idx++] = (Refrigerator)product.get(i);
			}
		}
		return result;
	}
	@Override
	public void deleteByPid(String pid) {// 상품번호로 상품 삭제
//		boolean exsist = false;
//		for (int i = 0; i < size; i++) {
//			if (product[i] instanceof TV && ((TV) product[i]).getPid().equals(pid)) {
//				product[i] = product[size - 1];
//				product[size - 1] = null;
//				size--;
//				exsist = true;
//			} else if (product[i] instanceof Refrigerator && ((Refrigerator) product[i]).getPid().equals(pid)) {
//				product[i] = product[size - 1];
//				product[size - 1] = null;
//				size--;
//				exsist = true;
//			}
//
//		}
//		if (exsist == false)
//			System.out.println("찾으시는 상품번호는 존재하지 않습니다.");
		product.removeIf(i -> (i.getPid().equals(pid)));

	}
	@Override
	public int printAllPrice() {// 전체 재고 상품 금액 구하기

//
//		for(int i= 0 ; i< size; i++) {
//			if (product[i] instanceof TV) {
//			sum +=(((TV) product[i]).getPnum()) * (((TV) product[i]).getPrice());
//			}
//			else if (product[i] instanceof Refrigerator){
//			sum +=(((Refrigerator) product[i]).getPnum()) * (((Refrigerator) product[i]).getPrice());
//			}
////			product[i]
////			
////			
////			if (product[i] instanceof TV) {// tv라면 tv에!
////				pn=((TV)product[i].getPnum());
////				pr=((TV)product[i].getPrice());
////				}
////	
////			else if (prd instanceof Refrigerator) {// 냉장고라면 냉장고에!
////				if (size <= MAX_SIZE)
////					product[size] = prd;// 들어오는 객체 저장
////				size += 1;
////				}
//			}
//		return sum;
	
		product.forEach(i -> sum +=i.getPnum()*i.getPrice());
		return sum;
	}
}
