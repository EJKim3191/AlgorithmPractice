package hwjava06_서울_8반_김응주;

public class TV extends Product{
	public int MAX_SIZE=100;
	TV [] Tv = new TV[MAX_SIZE];

//	
//	private String pid; //제품 번호
//	private String pname; //제품 이름
//	private int price; // 가격
//	private int pnum; // 수량
	private int pin; // 인치
	private String ptype; // 디스플레이 타입
	//constructor
	
	public TV(){
		
	}
	public TV(String pid, String pname, int price, int pnum, int pin,String ptype) {
		super(pid, pname, price, pnum);
		this.pin=pin;
		this.ptype=ptype;
	}
	//getter and setter
//	public String getPid() {
//		return pid;
//	}
//	public void setPid(String pid) {
//		this.pid = pid;
//	}
//	public String getPname() {
//		return pname;
//	}
//	public void setPname(String pname) {
//		this.pname = pname;
//	}
//	public int getPrice() {
//		return price;
//	}
//	public void setPrice(int price) {
//		this.price = price;
//	}
//	public int getPnum() {
//		return pnum;
//	}
//	public void setPnum(int pnum) {
//		this.pnum = pnum;
//	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public String getPtype() {
		return ptype;
	}
	public void setPtype(String ptype) {
		this.ptype = ptype;
	}
	


	//to string
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(super.toString());
		builder.append("|");
		builder.append(pin + "\t| ");
		builder.append(ptype);
		
		return builder.toString();
	}
}
