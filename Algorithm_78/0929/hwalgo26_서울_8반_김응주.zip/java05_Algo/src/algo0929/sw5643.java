package algo0929;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class sw5643 {
	public static int T;
	public static int N;
	public static int M;
	public static ArrayList<Node> arr=new ArrayList<>();
	public static Queue<Integer> q;
	public static boolean[] down;
	public static boolean[] up;
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer str = null;
		StringBuilder sb= new StringBuilder();
		T=Integer.parseInt(bfr.readLine());
		for(int testCase=1; testCase<=T; testCase++) {
			N=Integer.parseInt(bfr.readLine());
			M=Integer.parseInt(bfr.readLine());
			//입력부
			for(int i=0; i<N; i++) {
				str=new StringTokenizer(bfr.readLine());
				int from=Integer.parseInt(str.nextToken());
				int to=Integer.parseInt(str.nextToken());
				arr.add(new Node(from, to));
			}
			//연산
			//초기 생각->구하는 것은 자신의 위치를 알 수 있는 학생의 수
			//그 학생은 모든 노드와 연결되있다-> 비교연산이 가능하다 -> bfs 를 한방향으로 만 돌려 그 값들을 방문 했는지? 안했는지 확인 해 보면 풀 수 있지 않을까?
			//예를들어 4는 3, 2, 6, 5와 직접적으로 연결 되 있고, 1과는 한방향으로 연결 되어 있다
			int count=0;
			for(int i=1; i<=N; i++) {
				if(bfs(i)) {
					count+=1;
				}
			}
			sb.append("#").append(testCase).append(" ").append(count).append("\n");
		}
		System.out.println(sb);
	}
	public static boolean bfs(int start) {
		down=new boolean[N+1];
		up=new boolean[N+1];
		up[0]=true;
		down[0]=true;
		q=new LinkedList<>();
		
		q.add(start);
		//q.add(4);
		down[start]=true;
		up[start]=true;
		//from->to        down
		while(!q.isEmpty()) {
			int temp=q.poll();
			for(int i=0; i<arr.size(); i++) {
				if(arr.get(i).from==temp) {
					q.add(arr.get(i).to);
					down[arr.get(i).to]=true;
				}
			}
		}
		q.add(start);
		//to->from        up
		while(!q.isEmpty()) {
			int temp=q.poll();
			for(int i=0; i<arr.size(); i++) {
				if(arr.get(i).to==temp) {
					q.add(arr.get(i).from);
					up[arr.get(i).from]=true;
				}
			}
		}
		int cnt=0;
		for(int i=1; i<=N; i++) {
			if(down[i]==false && up[i]==false) break;
			
			cnt+=1;
		}
		//System.out.println(cnt);
		if(cnt==N) return true;
		return false;
	}
	//편리하게 관리하기 위한 노드 클래스 (from to)
	public static class Node{
		int from, to;

		/**
		 * @param from
		 * @param to
		 */
		public Node(int from, int to) {
			super();
			this.from = from;
			this.to = to;
		}
		
	}
}
