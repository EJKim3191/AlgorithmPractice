package hwjava07_서울_8반_김응주;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Stack;
import java.util.StringTokenizer;

public class Solution_16935 {
	private static int N;// y
	private static int M;// x
	private static int R;// 횟수
	private static int arr2[][];
	private static int arr3[][];
	private static Stack<Integer> stack = new Stack<>();

	public static void main(String[] args) throws IOException {
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer str = null;
		StringBuilder sb = new StringBuilder();

		str = new StringTokenizer(bfr.readLine());
		N = Integer.parseInt(str.nextToken());
		M = Integer.parseInt(str.nextToken());
		R = Integer.parseInt(str.nextToken());
		int Temnum=0;
		int[][] arr = new int[N][M];
		arr2 = new int[M][N]; // 3 ,4
		arr3 = new int[N][M]; // 5,6
		// 배열 할당
		for (int i = 0; i < N; i++) {
			str = new StringTokenizer(bfr.readLine());
			for (int j = 0; j < M; j++) {
				arr[i][j] = Integer.parseInt(str.nextToken());
			}
		}
		// 이동함수
		int rx = M - 1;
		int dy = N - 1;
		str = new StringTokenizer(bfr.readLine());
		for(int i=0; i<R; i++) {
			switch(Integer.parseInt(str.nextToken())) {
			case 1: 
				rotateUpsideDown(rx,0,0,dy, arr);
				break;
			case 2:
				rotateLeftRight(rx,0,0,dy, arr);
				break;
			case 3:
				arr = rotateRight90(rx, 0, 0, dy, arr);
				Temnum=rx;
				rx=dy;
				dy=Temnum;
				arr2=new int[M][N];
				arr3=new int[N][M];
				break;
			case 4:
				arr = rotateLeft90(rx, 0, 0, dy, arr);
				Temnum=rx;
				rx=dy;
				dy=Temnum;
				arr2=new int[M][N];
				arr3=new int[N][M];
				break;
			case 5:
				arr=subMoveClock(rx, 0, 0, dy, arr);
				arr2=new int[M][N];
				arr3=new int[N][M];
				break;
			case 6:
				arr=subAntiMoveClock(rx, 0, 0, dy, arr);
				arr2=new int[M][N];
				arr3=new int[N][M];
				break;
			}			
		}
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[0].length; j++) {
				sb.append(arr[i][j]).append(" ");
			}
			sb.append("\n");
		}
		System.out.println(sb);
		bfr.close();
	}

	public static void rotateUpsideDown(int rx, int lx, int uy, int dy, int arr[][]) {
		if (dy - uy <= 0)
			return;
		for (int k = lx; k <= rx; k++) {
			int temp = arr[uy][k];
			arr[uy][k] = arr[dy][k];
			arr[dy][k] = temp;
		}
		if (dy - uy >= 1)
			rotateUpsideDown(rx, lx, uy + 1, dy - 1, arr);
	}

	public static void rotateLeftRight(int rx, int lx, int uy, int dy, int arr[][]) {
		if (rx - lx <= 0)
			return;
		for (int k = uy; k <= dy; k++) {
			int temp = arr[k][lx];
			arr[k][lx] = arr[k][rx];
			arr[k][rx] = temp;
		}
		if (rx - lx >= 1)
			rotateLeftRight(rx - 1, lx + 1, uy, dy, arr);
	}

	public static int[][] rotateRight90(int rx, int lx, int uy, int dy, int arr[][]) {
		if(arr[0].length == arr2.length) {
			for (int j = lx; j <= rx; j++) {
				for (int i = dy; i >= uy; i--) {
					stack.add(arr[i][j]);
				}
				for (int i = dy; i >= uy; i--) {
					arr2[j][i] = stack.pop();
				}
			}
			arr = arr2;
			
		}
		else if(arr[0].length == arr3.length) {
			for (int j = lx; j <= rx; j++) {
				for (int i = dy; i >= uy; i--) {
					stack.add(arr[i][j]);
					// System.out.print(arr[i][j]);
				}
				for (int i = dy; i >= uy; i--) {
					arr3[j][i] = stack.pop();
				}
			}
			arr = arr3;
		}
		return arr;
	}

	public static int[][] rotateLeft90(int rx, int lx, int uy, int dy, int arr[][]) {
		rotateLeftRight(arr[0].length - 1, 0, 0, arr.length - 1, arr);
		rotateUpsideDown(arr[0].length - 1, 0, 0, arr.length - 1, arr);
		arr=rotateRight90(rx, lx, uy, dy, arr);
		
		return arr;
	}

	public static int[][] subMoveClock(int rx, int lx, int uy, int dy, int arr[][]) {
		if(arr[0].length == arr3[0].length) {
			for (int i = 0; i < (dy+1) / 2; i++) {
				for (int j = 0; j < (rx+1) / 2; j++) {
					arr3[i][(rx+1) / 2 + j] = arr[i][j];
				}
			}
			for (int i = 0; i < (dy+1) / 2; i++) {
				for (int j = (rx+1) / 2; j <(rx+1); j++) {
					arr3[i + (dy+1) / 2][j] = arr[i][j];
				}
			}
			for (int i = (dy+1) / 2; i < (dy+1); i++) {
				for (int j = (rx+1) / 2; j < (rx+1); j++) {
					arr3[i][j - (rx+1) / 2] = arr[i][j];
				}
			}
			for (int i = (dy+1) / 2; i < (dy+1); i++) {
				for (int j = 0; j < (rx+1) / 2; j++) {
					arr3[i - (dy+1) / 2][j] = arr[i][j];
				}
				
			}
			arr = arr3;
		}
		else if(arr[0].length == arr2[0].length) {
			for (int i = 0; i < (dy+1) / 2; i++) {
				for (int j = 0; j < (rx+1) / 2; j++) {
					arr2[i][(rx+1) / 2 + j] = arr[i][j];
				}
			}
			for (int i = 0; i < (dy+1) / 2; i++) {
				for (int j = (rx+1) / 2; j < (rx+1); j++) {
					arr2[i + (dy+1) / 2][j] = arr[i][j];
				}
			}
			for (int i = (dy+1) / 2; i < (dy+1); i++) {
				for (int j = (rx+1) / 2; j < (rx+1); j++) {
					arr2[i][j - (rx+1) / 2] = arr[i][j];
				}
			}
			for (int i = (dy+1) / 2; i < (dy+1); i++) {
				for (int j = 0; j < (rx+1) / 2; j++) {
					arr2[i - (dy+1) / 2][j] = arr[i][j];
				}
				
			}
			arr = arr2;
		}
		// arr = Arrays.stream(arr3).map(int[]::clone).toArray(int[][]::new);
		return arr;
	}

	public static int[][] subAntiMoveClock(int rx, int lx, int uy, int dy, int arr[][]) {
		if(arr[0].length == arr3[0].length) {
			for (int i = 0; i < (dy+1) / 2; i++) {
				for (int j = 0; j < (rx+1) / 2; j++) {
					arr3[(dy+1)/ 2 + i][j] = arr[i][j];
				}
			}
			for (int i = 0; i < (dy+1)  / 2; i++) {
				for (int j = (rx+1) / 2; j < (rx+1); j++) {
					arr3[i][j - (rx+1) / 2] = arr[i][j];
				}
			}
			for (int i = (dy+1)  / 2; i < (dy+1) ; i++) {
				for (int j = (rx+1) / 2; j < (rx+1); j++) {
					arr3[i - (dy+1)  / 2][j] = arr[i][j];
				}
			}
			for (int i = (dy+1)  / 2; i < (dy+1) ; i++) {
				for (int j = 0; j < (rx+1) / 2; j++) {
					arr3[i][j + (rx+1) / 2] = arr[i][j];
				}
			}
			arr = arr3;
		}
		else if(arr[0].length == arr3[0].length) {
			for (int i = 0; i < (dy+1) / 2; i++) {
				for (int j = 0; j < (rx+1) / 2; j++) {
					arr2[(dy+1)/ 2 + i][j] = arr[i][j];
				}
			}
			for (int i = 0; i < (dy+1)  / 2; i++) {
				for (int j = (rx+1) / 2; j < (rx+1); j++) {
					arr2[i][j - (rx+1) / 2] = arr[i][j];
				}
			}
			for (int i = (dy+1)  / 2; i < (dy+1) ; i++) {
				for (int j = (rx+1) / 2; j < (rx+1); j++) {
					arr2[i - (dy+1)  / 2][j] = arr[i][j];
				}
			}
			for (int i = (dy+1)  / 2; i < (dy+1) ; i++) {
				for (int j = 0; j < (rx+1) / 2; j++) {
					arr2[i][j + (rx+1) / 2] = arr[i][j];
				}
			}
			arr = arr2;
		}
		return arr;
	}

}
