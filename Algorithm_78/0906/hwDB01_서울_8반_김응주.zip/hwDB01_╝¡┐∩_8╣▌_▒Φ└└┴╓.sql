use ssafydb;
# 1번
create table Product
(pcode int(4) PRIMARY KEY,
pname VARCHAR(10),
price int(10));
# 2번
insert into Product(pcode, pname, price)
value('1234', 'TV', '1000000');

insert into Product(pcode, pname, price)
value('1235', 'TV', '3000000');

insert into Product(pcode, pname, price)
value('1236', 'TV', '1500000');

insert into Product(pcode, pname, price)
value('2312', '노트북', '800000');

insert into Product(pcode, pname, price)
value('2512', '노트북', '1200000');

insert into Product(pcode, pname, price)
value('2614', '노트북', '2000000');

select *
from Product;

#3번
select pcode, pname, round(price*(0.85),2) "15% 가격 인하"
from Product
group by pcode;

#4번
update Product set price=price*(0.8) where pname='TV';
select *
from Product
where pname='TV';

#5번
select sum(price) "총 금액"
from Product;

commit;